package desafio;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Denilson
 */
public class Usuario {

    private int primaryKey;

    private String nome;

    private String sobrenome;

    private String cpf;

    private String rg;

    private String date;

    private String rua;

    private String num;

    private String cep;

    private String bairro;

    private String cidade;

    private String estado;

    private String telefone;

    private String email;

    private String obs;

    private String pais;

    private UsuarioDAO con = new UsuarioDAO();
    private ResultSet rs = null;
    private PreparedStatement stm;

    public ResultSet consultar() {
        PreparedStatement stm;
        try {
            stm = con.getConexao().prepareStatement("select * from usuario");
            rs = stm.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    public boolean salvar() {

        String sql = "insert into usuario(id, nome, sobrenome, cpf, rg,"
                + " datnasc, rua, num, cep, bairro, cidade,"
                + " estado, telefone, email, obs, pais) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            PreparedStatement max = con.getConexao().prepareStatement("select max(id) as max from usuario");
            rs = max.executeQuery();
            rs.next();
            String maxPK = rs.getString("max");
            int MAXPK = 0;
            if (maxPK == null) {
                setPrimaryKey(1);
            } else {
                MAXPK = Integer.parseInt(maxPK);
                MAXPK++;
                setPrimaryKey(MAXPK);
            }
            PreparedStatement stm = con.getConexao().prepareStatement(sql);
            stm.setInt(1, this.primaryKey);
            stm.setString(2, this.nome);
            stm.setString(3, this.sobrenome);
            stm.setString(4, this.cpf);
            stm.setString(5, this.rg);
            stm.setString(6, this.date);
            stm.setString(7, this.rua);
            stm.setString(8, this.num);
            stm.setString(9, this.cep);
            stm.setString(10, this.bairro);
            stm.setString(11, this.cidade);
            stm.setString(12, this.estado);
            stm.setString(13, this.telefone);
            stm.setString(14, this.email);
            stm.setString(15, this.obs);
            stm.setString(16, this.pais);
            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);

        }
        return true;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(int primaryKey) {
        this.primaryKey = primaryKey;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    @Override
    public String toString() {
        return "Usuario{pais: " + getPais() + "primaryKey=" + primaryKey + ", nome=" + nome + ", sobrenome=" + sobrenome + ", cpf=" + cpf + ", rg=" + rg + ", date=" + date + ", rua=" + rua + ", num=" + num + ", cep=" + cep + ", bairro=" + bairro + ", cidade=" + cidade + ", estado=" + estado + ", telefone=" + telefone + ", email=" + email + ", obs=" + obs + '}';
    }

}
