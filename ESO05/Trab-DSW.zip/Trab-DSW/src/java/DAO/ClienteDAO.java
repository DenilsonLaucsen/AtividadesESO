/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClienteDAO {

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;
    private String nome;
    private int idade;
    private String rg;
    private String sexo;
    private String cnh;
    private LoginDAO login;

    public boolean Salvar() {

        String sql = "insert into cliente(nome, idade, rg, cnh, sexo, fk_idlogin) values (?, ?, ?, ?, ?, ?)";
        String sqlLogin = "insert into login(usuario, pass, tipo) values (?, ?, ?)";
        try {
            stm = con.getConexao().prepareStatement(sqlLogin);
            stm.setString(1, login.getUsuario());
            stm.setString(2, login.getPass());
            stm.setString(3, login.getTipo());
            stm.execute();

            PreparedStatement idLogin = con.getConexao().prepareStatement("select id as id from login where usuario = ?");
            idLogin.setString(1, login.getUsuario());
            rs = idLogin.executeQuery();
            rs.next();
            int idPK = rs.getInt("id");

            stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, this.nome);
            stm.setInt(2, this.idade);
            stm.setString(3, this.rg);
            stm.setString(4, this.cnh);
            stm.setString(5, this.sexo);
            stm.setInt(6, idPK);
            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public LoginDAO getLogin() {
        return login;
    }

    public void setLogin(LoginDAO login) {
        this.login = login;
    }

    //retorna a id login
    public int returnID(String rg) {
        String sql = "select fk_idlogin from cliente where rg = ?";

        try {
            stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, rg);
            rs = stm.executeQuery();
            rs.next();
            return rs.getInt("fk_idlogin");
        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

}
