/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;


public class CarroDAO {

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;
    private String carro;
    private String ano;
    private String KM;
    private String cor;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ResultSet consultar() {
        try {
            stm = con.getConexao().prepareStatement("Select * from carro where carro.id not in (select id_carro from locacaocarro)");
            rs = stm.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(CarroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    public boolean salvar() {

        String sql = "insert into carro(carro, km, cor, ano) values (?, ?, ?, ?)";

        try {
            stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, this.carro);
            stm.setString(2, this.KM);
            stm.setString(3, this.cor);
            stm.setString(4, this.ano);

            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public String getCarro() {
        return carro;
    }

    public void setCarro(String carro) {
        this.carro = carro;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public String getKM() {
        return KM;
    }

    public void setKM(String KM) {
        this.KM = KM;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

}
