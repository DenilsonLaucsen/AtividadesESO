/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.List;

/**
 *
 * @author Denilson
 */
public class Seguro {

    private String rg;
    private String nome;
    private String cnh;

    Seguro(long aLong, String string, String string0) {
        this.rg = "" + aLong;
        this.nome = string;
        this.cnh = string0;

    }

    Seguro() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public boolean salvar() {
        SeguroDAO cdao = new SeguroDAO();
        return cdao.salvar(this);
    }

    public boolean alterar() {
        SeguroDAO cdao = new SeguroDAO();
        return cdao.alterar(this);
    }

    public boolean excluir(String id) {
        SeguroDAO cdao = new SeguroDAO();
        return cdao.excluir(id);
    }

    public List<Seguro> consultar() {
        SeguroDAO cdao = new SeguroDAO();
        return cdao.consultar();
    }

}
