/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LocacaoDAO {

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;

    private int idCliente;
    private int idCarro;
    private int tempo;

    public boolean CancelarReserva(int carroID) {
        String sql = "delete from locacaocarro where id_carro = ?";

        try {
            stm = con.getConexao().prepareStatement(sql);
            stm.setInt(1, carroID);

            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;

    }

    public ResultSet consultaPeloClientei(Object id) {
        try {
            stm = con.getConexao().prepareStatement("Select * from carro inner join locacaocarro\n"
                    + "on carro.id = locacaocarro.id_carro\n"
                    + "where id_login = ?");
            stm.setInt(1, (int) id);
            rs = stm.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(CarroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    public boolean locar() {
        String sql = "insert into locacaocarro(id_login, id_carro, tempo) values (?, ?, ?)";

        try {
            stm = con.getConexao().prepareStatement(sql);
            stm.setInt(1, this.idCliente);
            stm.setInt(2, this.idCarro);
            stm.setInt(3, this.tempo);

            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public int getTempo() {
        return tempo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdCarro() {
        return idCarro;
    }

    public void setIdCarro(int idCarro) {
        this.idCarro = idCarro;
    }

}
