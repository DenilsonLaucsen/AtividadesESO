/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AtendenteDAO {

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;
    private String usuario;
    private String senha;
    private LoginDAO login;

    public boolean salvar() {
        String sql = "insert into login(usuario, pass, tipo) values (?, ?, ?)";

        try {
            PreparedStatement stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, this.usuario);
            stm.setString(2, this.senha);
            stm.setString(3, "atendente");
            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public LoginDAO getLogin() {
        return login;
    }

    public void setLogin(LoginDAO login) {
        this.login = login;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

}
