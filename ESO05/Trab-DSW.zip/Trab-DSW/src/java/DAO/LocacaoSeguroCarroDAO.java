/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LocacaoSeguroCarroDAO {

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;

    private int idCliente;
    private int idCarro;
    private int tempo;

    public boolean locar(int a) {
        String sqlReserva = "select * from locacaocarro where id_carro = ?";
//        String sqlApagaReserva = "delete from locacaocarro where id_carro = ?";
        String sql = "insert into locacaoseguro(id_login, id_carro, tempo) values (?, ?, ?)";

        try {
            stm = con.getConexao().prepareStatement(sqlReserva);
            stm.setInt(1, a);
            rs = stm.executeQuery();
            rs.next();
            stm = con.getConexao().prepareStatement(sql);
            stm.setInt(1, rs.getInt("id_login"));
            stm.setInt(2, rs.getInt("id_carro"));
            stm.setInt(3, rs.getInt("tempo"));
            stm.execute();
//            stm = con.getConexao().prepareStatement(sqlApagaReserva);
//            stm.setInt(1, a);
//
//            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public int getTempo() {
        return tempo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdCarro() {
        return idCarro;
    }

    public void setIdCarro(int idCarro) {
        this.idCarro = idCarro;
    }

}
