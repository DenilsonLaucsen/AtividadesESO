/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;

/**
 * REST Web Service
 *
 */
@Path("seguro")
public class SeguroWS {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GenericResource
     */
    List<Seguro> seguros = new ArrayList<>();

    public SeguroWS() {
        Seguro s = new Seguro();
        seguros = s.consultar();
    }

    /**
     * Retrieves representation of an instance of DAO.GenericResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String getSeguros() {
        Gson gson = new Gson();
        return gson.toJson(seguros);
    }

    @Path("{contatoId}")
    @GET
    @Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public String getSeguro(@PathParam("contatoId") String id) {
        for (Seguro c : seguros) {
            if (c.getRg().equals(Long.parseLong(id))) {
                Gson gson = new Gson();
                return gson.toJson(c);
            }
        }
        return null;
    }

    @Path("/inserir")
    @POST
    @Consumes(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public boolean inserirSeguro(String content) {
        Gson g = new Gson();
        Seguro c = (Seguro) g.fromJson(content, Seguro.class);
        //insere no banco de dados
        return c.salvar();
    }

    @PUT
    @Path("/alterar")
    @Consumes(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public boolean alterar(String content) {
        Gson g = new Gson();
        Seguro c = (Seguro) g.fromJson(content, Seguro.class);
        //altera o contato no banco de dados
        return c.alterar();
    }

    @DELETE
    @Path("/excluir/{contatoId}")
    // @Consumes(javax.ws.rs.core.MediaType.APPLICATION_JSON)
    public boolean excluir(@PathParam("contatoId") String id) {
        Seguro c = new Seguro();
        return c.excluir(id);
    }

    /**
     * PUT method for updating or creating an instance of GenericResource
     *
     * @param content representation for the resource
     * @return an HTTP response with content of the updated or created resource.
     */
    @PUT
    @Consumes("application/json")
    public void putJson(String content) {
    }
}
