/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LoginDAO {

    private String usuario;
    private String pass;
    private String tipo;
    private int id;

    public boolean salvar() {
        String sql = "insert into login(usuario, pass, tipo) values (?, ?, ?)";

        try {
            PreparedStatement stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, this.usuario);
            stm.setString(2, this.pass);
            stm.setString(3, this.tipo);
            stm.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;

    public String entrar(String usuario, String pass) {
        try {
            stm = con.getConexao().prepareStatement("select * from login where login.usuario = ?");
            stm.setString(1, usuario);
            rs = stm.executeQuery();

            rs.next();
            String userSQL = rs.getString("usuario");
            String passSQL = rs.getString("pass");
            String tipoSQL = rs.getString("tipo");
            if (userSQL.equals(usuario) && passSQL.equals(pass)) {
                this.usuario = userSQL;
                setId(rs.getInt("id"));
                this.pass = passSQL;
                this.tipo = tipoSQL;
                return tipoSQL;
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao Entrar");
        }
        return null;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

}
