/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Denilson
 */
public class SeguroDAO {

    private DAO con = new DAO();
    private ResultSet rs = null;
    private PreparedStatement stm;

    public boolean salvar(Seguro c) {
        String sql = "insert into seguro(nome, cnh, rg) values (?, ?, ?)";
        try {
            PreparedStatement stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, c.getNome());
            stm.setString(2, c.getCnh());
            stm.setString(3, c.getRg());
            stm.execute();
        } catch (SQLException ex) {
            Logger.getLogger(SeguroDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public boolean alterar(Seguro c) {
        String sql = "update seguro set nome=?, cnh=?, rg=? where id=?";
        try {
            PreparedStatement stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, c.getNome());
            stm.setString(2, c.getCnh());
            stm.setString(3, c.getRg());
            stm.execute();
        } catch (SQLException ex) {
            Logger.getLogger(SeguroDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public boolean excluir(String id) {
        String sql = "delete from seguro where id=?";
        try {
            PreparedStatement stm = con.getConexao().prepareStatement(sql);
            stm.setString(1, id);
            stm.execute();
        } catch (SQLException ex) {
            Logger.getLogger(SeguroDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public List<Seguro> consultar() {
        List<Seguro> lista = new ArrayList<>();
        try {
            PreparedStatement stm = con.getConexao().prepareStatement("select * from seguro");
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Seguro c
                        = new Seguro(rs.getLong("id"),
                                rs.getString("nome"),
                                rs.getString("fone"));
                lista.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SeguroDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
}
